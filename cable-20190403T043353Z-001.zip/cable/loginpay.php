<!DOCTYPE html>
<html>
<head>
<title>Connection</title>
</head>
<body>
<center>
<?php  $na='' ; $re=''; $add=''; $mo=''; $p1='';
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "not connected";}
$na=$_GET["uname"];
$am=$_GET["amnt"];
$cn=$_GET["cname"];
$ccn=$_GET["ccnum"];
$expm=$_GET["expmonth"];
$expy=$_GET["expyear"];
$cv=$_GET["cvv"];
$pn=$_GET["pin"];
$sql="insert into pay values('$na','$am','$cn','$ccn','$expm','$expy','$cv','$pn')";
if($connection->query($sql)===TRUE){echo "Registered Successfully/n";}
mysqli_close($connection);
?>
<form action="paid.html";>
<p style="text-align:center";>
<input type="submit" value="Back">
</form>
</center>
</body>
</html>
