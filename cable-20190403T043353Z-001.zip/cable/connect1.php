<!DOCTYPE html>
<html>
<head>
<title>Connection</title>
</head>
<body>
<center>
<?php  $na='';$re='';$add='';$mo='';$p1='';
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "connected";}
else
{echo "not connected";}
$na=$_GET["uname"];
$re=$_GET["reg"];
$add=$_GET["addr"];
$mo=$_GET["mob"];
$p1=$_GET["pwrd1"]; 


$sql="insert into register values('$na','$re','$add','$mo','$p1')";
if($connection->query($sql)===TRUE){echo "\nrecord inserted";}
else{echo "Error inserting record";}
mysqli_close($connection);
?>
<form action="lodin site.html" style="text-align:center">
<input type="submit" value="Back">
</form>
</center>
</body>
</html>