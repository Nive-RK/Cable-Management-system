<!DOCTYPE html>
<html>
<head>
<title>Connection</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 70%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 5px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
body {

 background-image:url(blu.jpg);
background-repeat: no-repeat;
background-size:cover;
}
</style>
</head>
<body>
<a href="list1.html" style="color:Black;"><b>Back</b></a>
<center>
<table>
<caption><h1>Customer payed List</h1></caption>
<tr>
<th>User Name</th>

<th>Amount</th> 

</tr>
</table> 
<?php  
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "not connected";}
$sql="select *from pay";
$result=mysqli_query($connection,$sql);
if($connection->query($sql)===TRUE){echo "payed customer list/n";}
mysqli_close($connection);
 Print "<table border cellpadding=3>"; 
while($row=mysqli_fetch_assoc($result))
{ 
 Print "<td>".$row['uname'] . "</td> "; 

 Print "<td>".$row['amnt'] . " </td></tr>"; 
 } 
 ?> 
</form>
</center>
</body>
</html>