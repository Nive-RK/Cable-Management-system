<!DOCTYPE html>
<html>
<head>
<title>CABLE BILLING SYSTEM </title>
</head>
<body>
<center>
<?php  $un='' ;  $p1='';
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "Not Connected Server Error";}
$na=$_GET["uname"];
$p1=$_GET["pwrd1"];
$sql="select * from register where uname='$na' and pwrd1='$p1' ";
$result=mysqli_query($connection,$sql);
$row=$result->fetch_assoc();
echo $row["uname"];
if($result->num_rows==1)
{
echo "\nlogged in";
include("list.html");
}
else
{
echo "Invalid Username or password";
include("lodin site.html");
}

?>
</center>
</body>
</html>