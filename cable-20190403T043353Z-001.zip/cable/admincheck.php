<!DOCTYPE html>
<html>
<head>
<title>CABLE BILLING SYSTEM </title>
</head>
<body>
<center>
<?php  $un='' ;  $p1='';
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "Not Connected Server Error";}
$ad=$_GET["aid"];
$pd=$_GET["pwrd"];
$sql="select * from admin where aid='$ad' and pwrd='$pd' ";
$result=mysqli_query($connection,$sql);
$row=$result->fetch_assoc();
echo $row["aid"];
if($result->num_rows==1)
{
echo "\nlogged in";
include("list1.html");
}
else
{
echo "Invalid Username or password";
include("admin.html");
}

?>
</center>
</body>
</html>