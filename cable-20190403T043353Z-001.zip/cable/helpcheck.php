<!DOCTYPE html>
<html>
<head>
<title>CABLE BILLING SYSTEM </title>
</head>
<body>
<center>
<?php  $un='' ;  $ad=''; $mb=''; $sub='';
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "Not Connected Server Error";}
$un=$_GET["uname"];
$ad=$_GET["addr"];
$mb=$_GET["mob"];
$sub=$_GET["subject"];

$sql="insert into help values('$un','$ad','$mb','$sub')";
if($connection->query($sql)===TRUE){echo "\nrecord inserted";}
else{echo "Error inserting record";}
mysqli_close($connection);
?>
<form action="confirm.html" style="text-align:center;">
<input type="submit" value="Back">
</form>
</center>
</body>
</html>

