<!DOCTYPE html>
<html>
<head>
<title>Connection</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 70%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 5px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
body{
		background-color:pink;
		}
</style>
</head>
<body>
<a href="list1.html" style="color:Black;"><b>Back</b></a>
<center>
<table>
<caption><h1>Customer Registered List</h1></caption>
<tr>
<th>User Name</th>
<th>Region</th> 
<th>Address</th> 
<th>Contact Num</th> 
<th>Password</th> 
</tr>
</table> 
<?php  
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "not connected";}
$sql="select *from register";
$result=mysqli_query($connection,$sql);
if($connection->query($sql)===TRUE){echo "Winners list/n";}
mysqli_close($connection);
 Print "<table border cellpadding=3>"; 
while($row=mysqli_fetch_assoc($result))
{ 
 Print "<td>".$row['uname'] . "</td> "; 
 Print "<td>".$row['reg'] . "</td> "; 
 Print "<td>".$row['addr'] . "</td> ";
  Print "<td>".$row['mob'] . "</td> ";
 Print "<td>".$row['pwrd1'] . " </td></tr>"; 
 } 
 ?> 
</form>
</center>
</body>
</html>