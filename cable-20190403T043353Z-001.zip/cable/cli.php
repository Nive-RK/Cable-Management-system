<!DOCTYPE html>
<html>
<head>
<title>Connection</title>
<style>
body{
		background-image:url("abc.jpg");
		background-size: cover;
		background-repeat:no-repeat;}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 70%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 5px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<a href="list1.html" style="color:Black;"><b>Back</b></a>
<center>
<table>
<caption><h1>Customer Help Request List</h1></caption>
<tr>
<th>User Name</th> 
<th>Address</th> 
<th>Contact Num</th> 
<th>Subject</th> 
</tr>
</table> 
<?php  
$servername="localhost";
$username="root";
$password="";
$dbname="cable";
$connection=mysqli_connect('localhost','root','','cable');
if($connection){echo "";}
else
{echo "not connected";}
$sql="select *from help";
$result=mysqli_query($connection,$sql);
if($connection->query($sql)===TRUE){echo "Help Request list/n";}
mysqli_close($connection);
 Print "<table border cellpadding=3>"; 
while($row=mysqli_fetch_assoc($result))
{ 
 Print "<td>".$row['uname'] . "</td> "; 
 Print "<td>".$row['addr'] . "</td> ";
  Print "<td>".$row['mob'] . "</td> ";
 Print "<td>".$row['subject'] . " </td></tr>"; 
 } 
 ?> 
</form>
</center>
</body>
</html>